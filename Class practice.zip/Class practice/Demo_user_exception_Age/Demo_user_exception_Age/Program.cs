﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_user_exception_Age
{
    class Program
    {
        static void Main(string[] args)
        {
            int age;
            Console.WriteLine("Enter your age in years:");
            //(Console.ReadLine());
            try
            {
                age = int.Parse(Console.ReadLine());
                if (age < 18)
                {
                    throw new Exception("You are kids !!!");
                }
                else
                {
                    Console.WriteLine("Permission granted!!!!");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

        }
    }
}

    
