﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Delegates
{
    class Program
    {
        public delegate void delmethod();

        public class P
        {

            public static void display()
            {
                Console.WriteLine("Hello!");
            }

            public static void show()
            {
                Console.WriteLine("Hi!");
            }

            public void print()
            {
                Console.WriteLine("Print");
            }

        }
        static void Main(string[] args)
        {
            delmethod del1 = P.show;

            delmethod del2 = new delmethod(P.display);
            P obj = new P();


            //delmethod del3 = obj.Print;

            del1();
            del2();
            //del3();

        }
    }
}

