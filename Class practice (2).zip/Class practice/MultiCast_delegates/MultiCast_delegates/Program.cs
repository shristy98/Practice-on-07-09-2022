﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MultiCast_delegates
{
    class Program
    {
        public delegate void delmethod(int x, int y);
        public class MultipleDelegate
        {
            public void Multication_Method1(int x, int y)
            {
                Console.Write("You are in Multiplication_Method");
                Console.WriteLine(x * y);
            }
            public void Plus_Method3(int x, int y)
            {
                Console.Write("You are in Plus_Method");
                Console.WriteLine(x + y);
            }

            public void subtract_Method2(int x, int y)
            {
                Console.Write("You are in subtraction_Method");
                Console.WriteLine(x - y);
            }
        }
            static void Main(string[] args)
        {
            MultipleDelegate obj = new MultipleDelegate();
            delmethod del = new delmethod(obj.Multication_Method1);

            // Here we have multicast  
            del += new delmethod(obj.subtract_Method2);
            // plus_Method1 and subtract_Method2 are called  
            del(50, 20);
            Console.WriteLine();

            del += new delmethod(obj.Plus_Method3);
            del(30, 40);
            Console.WriteLine();

            //Here again we have multicast  
            del = new delmethod(obj.Multication_Method1);
            //Only subtract_Method2 is called  
            del(25, 20);
            Console.WriteLine();
        }
    }
}
